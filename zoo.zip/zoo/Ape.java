public class Ape extends Primate {

    public Ape(String name, int age, double weight, int ability) {
        super(name, age, weight, ability);
        // TODO Auto-generated constructor stub
    }

    public void climb() {

        System.out.println("This animal (Ape ) is now climbing..");
    }
}
