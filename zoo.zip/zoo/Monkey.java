public class Monkey extends Primate {

    public Monkey(String name, int age, double weight, int ability) {
        super(name, age, weight, ability);
        // TODO Auto-generated constructor stub
    }

    public void climb() {

        System.out.println("This animal (monkey) is now climbing..");
    }
}
