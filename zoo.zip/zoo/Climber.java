public interface Climber {
    public default void climb() {
        System.out.println("This animal is now climbing...");
    }
}
